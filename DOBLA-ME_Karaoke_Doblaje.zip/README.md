# DOBLA-ME — Karaoke de Doblaje

Juego web de doblaje con estética cinematográfica.

## Incluye
- Biblioteca de escenas.
- Importación de video, imagen o audio.
- Portadas.
- Editor de diálogos sincronizados.
- Micrófono con permiso del navegador.
- Reconocimiento de voz cuando el navegador lo soporta.
- Medición de energía/volumen del micrófono.
- Puntuación por sincronización, palabras y energía.
- Combo y resultados.
- Cuenta regresiva.
- Controles de avance/retroceso.
- Persistencia local con IndexedDB.
- Diseño responsive para celular y PC.
- Sin dependencias externas.

## Formato de diálogos

PERSONAJE | INICIO | FIN | TEXTO

Ejemplo:

ALEX | 0 | 3.5 | ¿Dónde estabas?
SAM | 3.5 | 7 | Buscándote.
ALEX | 7 | 11 | Tenemos que hablar.

## Ejecutarlo

Puedes abrir `index.html` directamente para probar muchas funciones.

Para micrófono, lo recomendable es servirlo mediante HTTPS. GitHub Pages funciona porque entrega el sitio por HTTPS.

### GitHub Pages

1. Crea un repositorio.
2. Sube `index.html`, `style.css` y `app.js`.
3. En Settings > Pages selecciona la rama principal.
4. Abre la URL de GitHub Pages.
5. Permite el micrófono.

## Importante

La puntuación de voz es una aproximación basada en reconocimiento de voz, coincidencia de palabras, sincronización y energía del micrófono. No pretende medir calidad artística de la voz.

No se incluyen películas, series, canciones ni clips comerciales. El usuario debe importar contenido que tenga derecho a utilizar.
